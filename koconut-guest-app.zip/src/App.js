import { useState, useEffect, useCallback } from "react";

const STORAGE_KEY = "koconut_guests";
const VISITS_KEY = "koconut_visits";

const COLORS = {
  bg: "#0D1B1E", card: "#132226", cardBorder: "#1E3A3F",
  accent: "#E8A045", accentLight: "#F5C27A", teal: "#2EBFA5",
  tealDark: "#1A7A6A", red: "#E05252", text: "#F0EDE8",
  muted: "#8A9EA0", inputBg: "#0A1517", success: "#4CAF85",
};

const globalStyle = `
  @import url('https://fonts.googleapis.com/css2?family=Playfair+Display:wght@400;600;700&family=DM+Sans:wght@300;400;500;600&display=swap');
  * { box-sizing: border-box; margin: 0; padding: 0; }
  body { background: ${COLORS.bg}; color: ${COLORS.text}; font-family: 'DM Sans', sans-serif; }
  ::-webkit-scrollbar { width: 4px; }
  ::-webkit-scrollbar-track { background: ${COLORS.bg}; }
  ::-webkit-scrollbar-thumb { background: ${COLORS.tealDark}; border-radius: 2px; }
  @keyframes fadeIn { from { opacity:0; transform:translateY(8px); } to { opacity:1; transform:translateY(0); } }
  @keyframes pulse { 0%,100%{opacity:1} 50%{opacity:0.5} }
  @keyframes slideIn { from{transform:translateX(100%);opacity:0} to{transform:translateX(0);opacity:1} }
`;

// localStorage based storage for standalone web app
const storage = {
  get: (key) => {
    try { const v = localStorage.getItem(key); return v ? { value: v } : null; } catch { return null; }
  },
  set: (key, value) => {
    try { localStorage.setItem(key, value); return true; } catch { return false; }
  }
};

function Toast({ message, type, onClose }) {
  useEffect(() => { const t = setTimeout(onClose, 3000); return () => clearTimeout(t); }, [onClose]);
  return (
    <div style={{
      position:"fixed", top:20, right:20, zIndex:1000,
      background: type==="success" ? COLORS.success : COLORS.red,
      color:"#fff", padding:"12px 20px", borderRadius:10,
      fontFamily:"'DM Sans',sans-serif", fontWeight:500, fontSize:14,
      boxShadow:"0 8px 32px rgba(0,0,0,0.4)", animation:"slideIn 0.3s ease",
      display:"flex", alignItems:"center", gap:10
    }}>
      {type==="success" ? "✅" : "⚠️"} {message}
    </div>
  );
}

function StatCard({ label, value, icon, color }) {
  return (
    <div style={{
      background: COLORS.card, border:`1px solid ${COLORS.cardBorder}`,
      borderRadius:14, padding:"20px 24px", flex:1, minWidth:130,
      borderTop:`3px solid ${color}`, animation:"fadeIn 0.4s ease"
    }}>
      <div style={{fontSize:26, marginBottom:8}}>{icon}</div>
      <div style={{fontSize:28, fontWeight:700, color, fontFamily:"'Playfair Display',serif"}}>{value}</div>
      <div style={{fontSize:11, color:COLORS.muted, marginTop:4, textTransform:"uppercase", letterSpacing:1}}>{label}</div>
    </div>
  );
}

function Input({ label, ...props }) {
  return (
    <div style={{display:"flex", flexDirection:"column", gap:6}}>
      <label style={{fontSize:12, color:COLORS.muted, textTransform:"uppercase", letterSpacing:1}}>{label}</label>
      <input {...props} style={{
        background: COLORS.inputBg, border:`1px solid ${COLORS.cardBorder}`,
        borderRadius:8, padding:"10px 14px", color:COLORS.text,
        fontSize:14, fontFamily:"'DM Sans',sans-serif", width:"100%",
        ...(props.style||{})
      }}
      onFocus={e=>e.target.style.borderColor=COLORS.teal}
      onBlur={e=>e.target.style.borderColor=COLORS.cardBorder}
      />
    </div>
  );
}

export default function App() {
  const [tab, setTab] = useState("dashboard");
  const [guests, setGuests] = useState([]);
  const [visits, setVisits] = useState([]);
  const [search, setSearch] = useState("");
  const [toast, setToast] = useState(null);
  const [editGuest, setEditGuest] = useState(null);
  const [viewGuest, setViewGuest] = useState(null);
  const [form, setForm] = useState({ name:"", phone:"", pax:"1", dob:"", anniversary:"", notes:"" });

  useEffect(() => {
    const g = storage.get(STORAGE_KEY);
    const v = storage.get(VISITS_KEY);
    if (g) setGuests(JSON.parse(g.value));
    if (v) setVisits(JSON.parse(v.value));
  }, []);

  const saveGuests = useCallback((g) => { storage.set(STORAGE_KEY, JSON.stringify(g)); }, []);
  const saveVisits = useCallback((v) => { storage.set(VISITS_KEY, JSON.stringify(v)); }, []);

  const showToast = (message, type="success") => setToast({ message, type });
  const resetForm = () => setForm({ name:"", phone:"", pax:"1", dob:"", anniversary:"", notes:"" });

  const handleAddGuest = () => {
    if (!form.name.trim() || !form.phone.trim()) return showToast("नाव आणि phone number आवश्यक आहे", "error");
    if (!/^\d{10}$/.test(form.phone)) return showToast("10 अंकी phone number टाका", "error");
    if (guests.find(g => g.phone === form.phone)) return showToast("हा phone number आधीच registered आहे", "error");
    const newGuest = {
      id: Date.now().toString(), name: form.name.trim(), phone: form.phone.trim(),
      pax: parseInt(form.pax)||1, dob: form.dob, anniversary: form.anniversary,
      notes: form.notes.trim(), createdAt: new Date().toISOString(),
    };
    const newVisit = { id: Date.now().toString()+"v", guestId: newGuest.id, date: new Date().toISOString(), pax: newGuest.pax };
    const ng = [...guests, newGuest]; const nv = [...visits, newVisit];
    setGuests(ng); setVisits(nv); saveGuests(ng); saveVisits(nv);
    resetForm(); showToast(`${newGuest.name} ला welcome केले! 🎉`); setTab("guests");
  };

  const handleUpdateGuest = () => {
    const updated = guests.map(g => g.id === editGuest.id ? { ...g, ...form, pax: parseInt(form.pax)||1 } : g);
    setGuests(updated); saveGuests(updated); setEditGuest(null); resetForm();
    showToast("Guest माहिती update झाली ✓");
  };

  const handleMarkVisit = (guest) => {
    const nv = [...visits, { id: Date.now().toString()+"v", guestId: guest.id, date: new Date().toISOString(), pax: guest.pax }];
    setVisits(nv); saveVisits(nv); showToast(`${guest.name} चा visit record झाला! 🍽️`);
  };

  const handleDeleteGuest = (id) => {
    const ng = guests.filter(g=>g.id!==id); const nv = visits.filter(v=>v.guestId!==id);
    setGuests(ng); setVisits(nv); saveGuests(ng); saveVisits(nv);
    setViewGuest(null); showToast("Guest काढला", "error");
  };

  const getVisitCount = (guestId) => visits.filter(v=>v.guestId===guestId).length;
  const getLastVisit = (guestId) => {
    const gv = visits.filter(v=>v.guestId===guestId).sort((a,b)=>new Date(b.date)-new Date(a.date));
    return gv[0] ? new Date(gv[0].date).toLocaleDateString("mr-IN") : "—";
  };

  const today = new Date();
  const todayMD = `${String(today.getMonth()+1).padStart(2,"0")}-${String(today.getDate()).padStart(2,"0")}`;
  const tomorrowD = new Date(today); tomorrowD.setDate(today.getDate()+1);
  const tomorrowMD = `${String(tomorrowD.getMonth()+1).padStart(2,"0")}-${String(tomorrowD.getDate()).padStart(2,"0")}`;

  const birthdayToday = guests.filter(g=>g.dob&&g.dob.slice(5)===todayMD);
  const anniversaryToday = guests.filter(g=>g.anniversary&&g.anniversary.slice(5)===todayMD);
  const birthdayTomorrow = guests.filter(g=>g.dob&&g.dob.slice(5)===tomorrowMD);
  const anniversaryTomorrow = guests.filter(g=>g.anniversary&&g.anniversary.slice(5)===tomorrowMD);
  const regularGuests = guests.filter(g=>getVisitCount(g.id)>=3).length;
  const filteredGuests = guests.filter(g=>g.name.toLowerCase().includes(search.toLowerCase())||g.phone.includes(search));

  const tabs = [
    { id:"dashboard", label:"Dashboard", icon:"📊" },
    { id:"entry", label:"New Entry", icon:"➕" },
    { id:"guests", label:"Guests", icon:"👥" },
    { id:"alerts", label:"Alerts", icon:"🔔", badge: birthdayToday.length+anniversaryToday.length },
    { id:"reports", label:"Reports", icon:"📈" },
  ];

  return (
    <div style={{minHeight:"100vh", background:COLORS.bg}}>
      <style>{globalStyle}</style>
      {toast && <Toast {...toast} onClose={()=>setToast(null)} />}

      {/* HEADER */}
      <div style={{background:COLORS.card, borderBottom:`1px solid ${COLORS.cardBorder}`, padding:"14px 20px", display:"flex", alignItems:"center", justifyContent:"space-between", position:"sticky", top:0, zIndex:100}}>
        <div style={{display:"flex", alignItems:"center", gap:12}}>
          <span style={{fontSize:26}}>🥥</span>
          <div>
            <div style={{fontFamily:"'Playfair Display',serif", fontSize:17, fontWeight:700, color:COLORS.accent}}>Koconut Tree</div>
            <div style={{fontSize:10, color:COLORS.muted, letterSpacing:1, textTransform:"uppercase"}}>Guest Management</div>
          </div>
        </div>
        <div style={{fontSize:12, color:COLORS.muted}}>
          {today.toLocaleDateString("mr-IN", {day:"numeric", month:"long", year:"numeric"})}
        </div>
      </div>

      {/* TABS */}
      <div style={{background:COLORS.card, borderBottom:`1px solid ${COLORS.cardBorder}`, display:"flex", overflowX:"auto", padding:"0 12px"}}>
        {tabs.map(t=>(
          <button key={t.id} onClick={()=>setTab(t.id)} style={{
            background:"none", border:"none", cursor:"pointer", padding:"13px 16px",
            color: tab===t.id ? COLORS.accent : COLORS.muted,
            borderBottom: tab===t.id ? `2px solid ${COLORS.accent}` : "2px solid transparent",
            fontSize:13, fontFamily:"'DM Sans',sans-serif", fontWeight:500,
            display:"flex", alignItems:"center", gap:5, whiteSpace:"nowrap"
          }}>
            {t.icon} {t.label}
            {t.badge>0 && <span style={{background:COLORS.red,color:"#fff",borderRadius:10,fontSize:10,padding:"1px 6px",fontWeight:700}}>{t.badge}</span>}
          </button>
        ))}
      </div>

      <div style={{maxWidth:900, margin:"0 auto", padding:"20px 16px"}}>

        {/* DASHBOARD */}
        {tab==="dashboard" && (
          <div style={{animation:"fadeIn 0.4s ease"}}>
            <h2 style={{fontFamily:"'Playfair Display',serif", fontSize:20, color:COLORS.accent, marginBottom:4}}>
              Good {today.getHours()<12?"Morning":today.getHours()<17?"Afternoon":"Evening"} 👋
            </h2>
            <p style={{color:COLORS.muted, fontSize:13, marginBottom:20}}>Magarpatta, Pune — आजचा overview</p>
            <div style={{display:"flex", gap:12, flexWrap:"wrap", marginBottom:20}}>
              <StatCard label="Total Guests" value={guests.length} icon="👥" color={COLORS.teal} />
              <StatCard label="Total Visits" value={visits.length} icon="🍽️" color={COLORS.accent} />
              <StatCard label="Regular (3+)" value={regularGuests} icon="⭐" color={COLORS.accentLight} />
              <StatCard label="Today Alerts" value={birthdayToday.length+anniversaryToday.length} icon="🔔" color={COLORS.red} />
            </div>

            {(birthdayToday.length>0||anniversaryToday.length>0) && (
              <div style={{background:"linear-gradient(135deg,#1A3A2A,#1E3520)", border:`1px solid #2A5A3A`, borderRadius:14, padding:18, marginBottom:18}}>
                <div style={{color:COLORS.success, fontWeight:600, marginBottom:10, fontSize:14}}>🎉 आजचे Special Guests</div>
                {birthdayToday.map(g=>(
                  <div key={g.id} style={{display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:`1px solid rgba(255,255,255,0.05)`, fontSize:14}}>
                    <span>🎂 <strong>{g.name}</strong> — वाढदिवस!</span>
                    <a href={`https://wa.me/91${g.phone}?text=${encodeURIComponent(`🎂 नमस्ते ${g.name}! Koconut Tree तर्फे वाढदिवसाच्या शुभेच्छा! 🥥 आज आमच्याकडे या — special treat आहे तुमच्यासाठी! 🎉`)}`} target="_blank" rel="noreferrer" style={{background:"#25D366",color:"#fff",borderRadius:6,padding:"4px 10px",fontSize:12,fontWeight:600,textDecoration:"none"}}>WhatsApp</a>
                  </div>
                ))}
                {anniversaryToday.map(g=>(
                  <div key={g.id} style={{display:"flex", justifyContent:"space-between", padding:"8px 0", borderBottom:`1px solid rgba(255,255,255,0.05)`, fontSize:14}}>
                    <span>💑 <strong>{g.name}</strong> — Anniversary!</span>
                    <a href={`https://wa.me/91${g.phone}?text=${encodeURIComponent(`💑 नमस्ते ${g.name}! Koconut Tree तर्फे Anniversary च्या शुभेच्छा! 🥥 आज आमच्याकडे या — special evening तुमची वाट पाहत आहे! 🎉`)}`} target="_blank" rel="noreferrer" style={{background:"#25D366",color:"#fff",borderRadius:6,padding:"4px 10px",fontSize:12,fontWeight:600,textDecoration:"none"}}>WhatsApp</a>
                  </div>
                ))}
              </div>
            )}

            <div style={{background:COLORS.card, border:`1px solid ${COLORS.cardBorder}`, borderRadius:14, padding:18}}>
              <div style={{fontWeight:600, marginBottom:14, fontSize:14}}>🕐 Recent Visits</div>
              {visits.length===0 && <div style={{color:COLORS.muted, fontSize:13}}>अजून कोणतेही visits नाहीत</div>}
              {visits.slice(-8).reverse().map(v=>{
                const g=guests.find(x=>x.id===v.guestId); if(!g) return null;
                return (
                  <div key={v.id} style={{display:"flex", justifyContent:"space-between", alignItems:"center", padding:"9px 0", borderBottom:`1px solid ${COLORS.cardBorder}`, fontSize:14}}>
                    <div style={{display:"flex", alignItems:"center", gap:10}}>
                      <div style={{width:34,height:34,borderRadius:"50%",background:COLORS.tealDark,display:"flex",alignItems:"center",justifyContent:"center",fontWeight:700}}>{g.name[0].toUpperCase()}</div>
                      <div>
                        <div style={{fontWeight:500}}>{g.name}</div>
                        <div style={{fontSize:11,color:COLORS.muted}}>{v.pax} pax</div>
                      </div>
                    </div>
                    <div style={{fontSize:12,color:COLORS.muted}}>{new Date(v.date).toLocaleDateString("mr-IN")}</div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* NEW ENTRY */}
        {tab==="entry" && (
          <div style={{animation:"fadeIn 0.4s ease"}}>
            <h2 style={{fontFamily:"'Playfair Display',serif", fontSize:20, color:COLORS.accent, marginBottom:18}}>
              {editGuest ? "✏️ Guest Update करा" : "➕ नवीन Guest Entry"}
            </h2>
            <div style={{background:COLORS.card, border:`1px solid ${COLORS.cardBorder}`, borderRadius:16, padding:24}}>
              <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:14, marginBottom:14}}>
                <Input label="Guest नाव *" placeholder="उदा. राहुल शर्मा" value={form.name} onChange={e=>setForm({...form,name:e.target.value})} />
                <Input label="Phone Number *" placeholder="10 अंक" value={form.phone} onChange={e=>setForm({...form,phone:e.target.value})} maxLength={10} />
              </div>
              <div style={{display:"grid", gridTemplateColumns:"1fr 1fr 1fr", gap:14, marginBottom:14}}>
                <Input label="No. of Pax" type="number" min="1" max="50" value={form.pax} onChange={e=>setForm({...form,pax:e.target.value})} />
                <Input label="वाढदिवस (DOB)" type="date" value={form.dob} onChange={e=>setForm({...form,dob:e.target.value})} />
                <Input label="Anniversary" type="date" value={form.anniversary} onChange={e=>setForm({...form,anniversary:e.target.value})} />
              </div>
              <div style={{marginBottom:18}}>
                <Input label="Notes / Food Preferences" placeholder="उदा. Seafood allergic, window seat prefer..." value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} />
              </div>
              <div style={{display:"flex", gap:10}}>
                <button onClick={editGuest ? handleUpdateGuest : handleAddGuest} style={{
                  background:`linear-gradient(135deg,${COLORS.teal},${COLORS.tealDark})`,
                  border:"none", borderRadius:10, padding:"12px 24px",
                  color:"#fff", fontSize:14, fontWeight:600, cursor:"pointer",
                  fontFamily:"'DM Sans',sans-serif", flex:1
                }}>
                  {editGuest ? "✅ Update करा" : "🎉 Guest Add करा + Visit Mark करा"}
                </button>
                {editGuest && (
                  <button onClick={()=>{setEditGuest(null);resetForm();}} style={{background:"none",border:`1px solid ${COLORS.cardBorder}`,borderRadius:10,padding:"12px 18px",color:COLORS.muted,cursor:"pointer",fontFamily:"'DM Sans',sans-serif"}}>Cancel</button>
                )}
              </div>
            </div>
          </div>
        )}

        {/* GUEST LIST */}
        {tab==="guests" && (
          <div style={{animation:"fadeIn 0.4s ease"}}>
            <div style={{display:"flex", justifyContent:"space-between", alignItems:"center", marginBottom:18, flexWrap:"wrap", gap:10}}>
              <h2 style={{fontFamily:"'Playfair Display',serif", fontSize:20, color:COLORS.accent}}>👥 All Guests ({guests.length})</h2>
              <input placeholder="🔍 नाव किंवा phone..." value={search} onChange={e=>setSearch(e.target.value)} style={{background:COLORS.inputBg,border:`1px solid ${COLORS.cardBorder}`,borderRadius:8,padding:"8px 14px",color:COLORS.text,fontSize:13,fontFamily:"'DM Sans',sans-serif",width:220}} />
            </div>
            {filteredGuests.length===0 && (
              <div style={{textAlign:"center", padding:50, color:COLORS.muted}}>
                <div style={{fontSize:36, marginBottom:10}}>🔍</div>
                <div>{guests.length===0 ? "अजून कोणताही guest नाही. New Entry मध्ये जा!" : "कोणताही guest सापडला नाही"}</div>
              </div>
            )}
            <div style={{display:"flex", flexDirection:"column", gap:10}}>
              {filteredGuests.sort((a,b)=>getVisitCount(b.id)-getVisitCount(a.id)).map(g=>{
                const vc=getVisitCount(g.id);
                const isBday=g.dob&&g.dob.slice(5)===todayMD;
                const isAnni=g.anniversary&&g.anniversary.slice(5)===todayMD;
                return (
                  <div key={g.id} style={{background:COLORS.card, border:`1px solid ${(isBday||isAnni)?COLORS.accent:COLORS.cardBorder}`, borderRadius:12, padding:"14px 18px", display:"flex", justifyContent:"space-between", alignItems:"center"}}>
                    <div style={{display:"flex", alignItems:"center", gap:12}}>
                      <div style={{width:42,height:42,borderRadius:"50%",background:`linear-gradient(135deg,${COLORS.teal},${COLORS.tealDark})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:17,fontWeight:700}}>{g.name[0].toUpperCase()}</div>
                      <div>
                        <div style={{fontWeight:600, fontSize:14}}>{g.name}{isBday&&" 🎂"}{isAnni&&" 💑"}</div>
                        <div style={{fontSize:11,color:COLORS.muted}}>📞 {g.phone} · Last: {getLastVisit(g.id)}</div>
                      </div>
                    </div>
                    <div style={{display:"flex", alignItems:"center", gap:8}}>
                      <div style={{textAlign:"center", minWidth:50}}>
                        <div style={{fontSize:18,fontWeight:700,color:vc>=5?COLORS.accent:vc>=3?COLORS.teal:COLORS.muted}}>{vc}</div>
                        <div style={{fontSize:10,color:COLORS.muted}}>visits</div>
                      </div>
                      <button onClick={()=>handleMarkVisit(g)} title="Visit Mark" style={{background:COLORS.tealDark,border:"none",borderRadius:7,padding:"6px 9px",cursor:"pointer",fontSize:15}}>🍽️</button>
                      <button onClick={()=>{setEditGuest(g);setForm({name:g.name,phone:g.phone,pax:String(g.pax),dob:g.dob||"",anniversary:g.anniversary||"",notes:g.notes||""});setTab("entry");}} title="Edit" style={{background:"#1A2E35",border:"none",borderRadius:7,padding:"6px 9px",cursor:"pointer",fontSize:15}}>✏️</button>
                      <button onClick={()=>setViewGuest(g)} title="Details" style={{background:"#1A2E35",border:"none",borderRadius:7,padding:"6px 9px",cursor:"pointer",fontSize:15}}>👁️</button>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {/* ALERTS */}
        {tab==="alerts" && (
          <div style={{animation:"fadeIn 0.4s ease"}}>
            <h2 style={{fontFamily:"'Playfair Display',serif", fontSize:20, color:COLORS.accent, marginBottom:18}}>🔔 Birthday & Anniversary Alerts</h2>
            {[
              {label:"🎂 आजचे वाढदिवस", list:birthdayToday, color:COLORS.success, type:"Birthday"},
              {label:"💑 आजच्या Anniversaries", list:anniversaryToday, color:"#E91E8C", type:"Anniversary"},
              {label:"🎂 उद्याचे वाढदिवस", list:birthdayTomorrow, color:COLORS.teal, type:"Birthday"},
              {label:"💑 उद्याच्या Anniversaries", list:anniversaryTomorrow, color:COLORS.accent, type:"Anniversary"},
            ].map(section=>(
              <div key={section.label} style={{background:COLORS.card,border:`1px solid ${COLORS.cardBorder}`,borderRadius:14,padding:18,marginBottom:14}}>
                <div style={{fontWeight:600,color:section.color,marginBottom:10,fontSize:14}}>{section.label} ({section.list.length})</div>
                {section.list.length===0 ? <div style={{color:COLORS.muted,fontSize:13}}>आज कोणाचा नाही</div>
                  : section.list.map(g=>(
                    <div key={g.id} style={{display:"flex",justifyContent:"space-between",alignItems:"center",padding:"9px 0",borderBottom:`1px solid ${COLORS.cardBorder}`,fontSize:14}}>
                      <div>
                        <span style={{fontWeight:600}}>{g.name}</span>
                        <span style={{color:COLORS.muted,fontSize:12,marginLeft:8}}>{g.pax} pax · {g.phone}</span>
                      </div>
                      <a href={`https://wa.me/91${g.phone}?text=${encodeURIComponent(
                        section.type==="Birthday"
                          ? `🎂 नमस्ते ${g.name}! Koconut Tree Bar & Kitchen तर्फे तुम्हाला वाढदिवसाच्या खूप खूप शुभेच्छा! 🥥 आज आमच्याकडे या आणि special treat enjoy करा. 🎉`
                          : `💑 नमस्ते ${g.name}! Koconut Tree Bar & Kitchen तर्फे Anniversary च्या खूप खूप शुभेच्छा! 🥥 आज आमच्याकडे या — special evening तुमची वाट पाहत आहे! 🌟`
                      )}`} target="_blank" rel="noreferrer" style={{background:"#25D366",color:"#fff",borderRadius:7,padding:"6px 12px",fontSize:12,fontWeight:600,textDecoration:"none"}}>
                        WhatsApp पाठवा
                      </a>
                    </div>
                  ))
                }
              </div>
            ))}
          </div>
        )}

        {/* REPORTS */}
        {tab==="reports" && (
          <div style={{animation:"fadeIn 0.4s ease"}}>
            <h2 style={{fontFamily:"'Playfair Display',serif", fontSize:20, color:COLORS.accent, marginBottom:18}}>📈 Reports & Analytics</h2>
            <div style={{display:"grid", gridTemplateColumns:"1fr 1fr", gap:14, marginBottom:16}}>
              <div style={{background:COLORS.card,border:`1px solid ${COLORS.cardBorder}`,borderRadius:14,padding:18}}>
                <div style={{fontWeight:600,marginBottom:12,color:COLORS.teal,fontSize:14}}>🏆 Top Regular Guests</div>
                {guests.sort((a,b)=>getVisitCount(b.id)-getVisitCount(a.id)).slice(0,6).map((g,i)=>(
                  <div key={g.id} style={{display:"flex",justifyContent:"space-between",padding:"6px 0",borderBottom:`1px solid ${COLORS.cardBorder}`,fontSize:13}}>
                    <span><span style={{color:COLORS.muted,marginRight:6}}>#{i+1}</span>{g.name}</span>
                    <span style={{color:COLORS.accent,fontWeight:600}}>{getVisitCount(g.id)} visits</span>
                  </div>
                ))}
                {guests.length===0 && <div style={{color:COLORS.muted,fontSize:13}}>अजून data नाही</div>}
              </div>
              <div style={{background:COLORS.card,border:`1px solid ${COLORS.cardBorder}`,borderRadius:14,padding:18}}>
                <div style={{fontWeight:600,marginBottom:12,color:COLORS.teal,fontSize:14}}>📊 Loyalty Breakdown</div>
                {[
                  {label:"नवीन (1 visit)", count:guests.filter(g=>getVisitCount(g.id)===1).length, color:COLORS.muted},
                  {label:"येणारे (2 visits)", count:guests.filter(g=>getVisitCount(g.id)===2).length, color:COLORS.teal},
                  {label:"Regular (3-5)", count:guests.filter(g=>getVisitCount(g.id)>=3&&getVisitCount(g.id)<=5).length, color:COLORS.accent},
                  {label:"VIP (6+ visits)", count:guests.filter(g=>getVisitCount(g.id)>=6).length, color:COLORS.accentLight},
                ].map(row=>(
                  <div key={row.label} style={{marginBottom:10}}>
                    <div style={{display:"flex",justifyContent:"space-between",marginBottom:3,fontSize:12}}>
                      <span style={{color:COLORS.muted}}>{row.label}</span>
                      <span style={{color:row.color,fontWeight:600}}>{row.count}</span>
                    </div>
                    <div style={{background:COLORS.inputBg,borderRadius:4,height:5}}>
                      <div style={{background:row.color,borderRadius:4,height:5,width:guests.length?`${Math.min(100,(row.count/guests.length)*100)}%`:"0%"}}/>
                    </div>
                  </div>
                ))}
              </div>
            </div>
            <div style={{background:COLORS.card,border:`1px solid ${COLORS.cardBorder}`,borderRadius:14,padding:18}}>
              <div style={{fontWeight:600,marginBottom:12,color:COLORS.teal,fontSize:14}}>📅 या महिन्यातील Special Days</div>
              {(() => {
                const m=today.getMonth()+1;
                const upcoming=guests.filter(g=>(g.dob&&parseInt(g.dob.split("-")[1])===m)||(g.anniversary&&parseInt(g.anniversary.split("-")[1])===m));
                return upcoming.length===0
                  ? <div style={{color:COLORS.muted,fontSize:13}}>या महिन्यात कोणाचे special days नाहीत</div>
                  : upcoming.map(g=>(
                    <div key={g.id} style={{display:"flex",justifyContent:"space-between",padding:"7px 0",borderBottom:`1px solid ${COLORS.cardBorder}`,fontSize:13}}>
                      <span>{g.name}</span>
                      <span style={{color:COLORS.muted}}>
                        {g.dob&&parseInt(g.dob.split("-")[1])===m&&`🎂 ${g.dob.slice(5).replace("-","/")} `}
                        {g.anniversary&&parseInt(g.anniversary.split("-")[1])===m&&`💑 ${g.anniversary.slice(5).replace("-","/")} `}
                      </span>
                    </div>
                  ));
              })()}
            </div>
          </div>
        )}
      </div>

      {/* GUEST DETAIL MODAL */}
      {viewGuest && (
        <div onClick={()=>setViewGuest(null)} style={{position:"fixed",inset:0,background:"rgba(0,0,0,0.75)",display:"flex",alignItems:"center",justifyContent:"center",zIndex:200,padding:16}}>
          <div onClick={e=>e.stopPropagation()} style={{background:COLORS.card,border:`1px solid ${COLORS.cardBorder}`,borderRadius:16,padding:24,width:"100%",maxWidth:420,animation:"fadeIn 0.3s ease"}}>
            <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",marginBottom:18}}>
              <div style={{display:"flex",alignItems:"center",gap:12}}>
                <div style={{width:48,height:48,borderRadius:"50%",background:`linear-gradient(135deg,${COLORS.teal},${COLORS.tealDark})`,display:"flex",alignItems:"center",justifyContent:"center",fontSize:20,fontWeight:700}}>{viewGuest.name[0].toUpperCase()}</div>
                <div>
                  <div style={{fontFamily:"'Playfair Display',serif",fontSize:18,fontWeight:700}}>{viewGuest.name}</div>
                  <div style={{color:COLORS.teal,fontSize:12}}>{getVisitCount(viewGuest.id)} visits · Last: {getLastVisit(viewGuest.id)}</div>
                </div>
              </div>
              <button onClick={()=>setViewGuest(null)} style={{background:"none",border:"none",color:COLORS.muted,fontSize:20,cursor:"pointer"}}>✕</button>
            </div>
            {[
              ["📞 Phone", viewGuest.phone],
              ["👥 Pax", viewGuest.pax],
              ["🎂 DOB", viewGuest.dob ? new Date(viewGuest.dob).toLocaleDateString("mr-IN") : "—"],
              ["💑 Anniversary", viewGuest.anniversary ? new Date(viewGuest.anniversary).toLocaleDateString("mr-IN") : "—"],
              ["📝 Notes", viewGuest.notes || "—"],
            ].map(([k,v])=>(
              <div key={k} style={{display:"flex",justifyContent:"space-between",padding:"9px 0",borderBottom:`1px solid ${COLORS.cardBorder}`,fontSize:13}}>
                <span style={{color:COLORS.muted}}>{k}</span>
                <span style={{fontWeight:500}}>{v}</span>
              </div>
            ))}
            <div style={{display:"flex",gap:10,marginTop:18}}>
              <button onClick={()=>{handleMarkVisit(viewGuest);setViewGuest(null);}} style={{flex:1,background:`linear-gradient(135deg,${COLORS.teal},${COLORS.tealDark})`,border:"none",borderRadius:10,padding:"11px",color:"#fff",fontWeight:600,cursor:"pointer",fontFamily:"'DM Sans',sans-serif",fontSize:13}}>🍽️ Visit Mark करा</button>
              <button onClick={()=>handleDeleteGuest(viewGuest.id)} style={{background:"none",border:`1px solid ${COLORS.red}`,borderRadius:10,padding:"11px 14px",color:COLORS.red,cursor:"pointer"}}>🗑️</button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
